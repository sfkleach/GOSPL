GOSPL Contributions
===================

I have thinned out this area very considerably in the latest release of
GOSPL.  The only item I have selected is Tom Khabaza's OPS5 release
for Poplog.

-- Contributions ------------------------------------------------------------

ops5.tar.gz
    Poplog Common Lisp distribution of the public domain OPS5 package.
    Made available by Tom Khabaza, 12th June 1989.

-----------------------------------------------------------------------------
